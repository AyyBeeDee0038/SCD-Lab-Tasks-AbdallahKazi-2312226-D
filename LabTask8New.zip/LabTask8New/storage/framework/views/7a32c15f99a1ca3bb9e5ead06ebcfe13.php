<!DOCTYPE html>
<html>
<head>
    <title>Verify Email</title>
</head>
<body>
    <h2>Hello, <?php echo e($user->name); ?></h2>
    <p>Please click the link below to verify your email address:</p>
    <a href="<?php echo e(url('/verify/' . $user->id)); ?>">Verify My Account</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\LabTask8New\resources\views/emails/verify.blade.php ENDPATH**/ ?>