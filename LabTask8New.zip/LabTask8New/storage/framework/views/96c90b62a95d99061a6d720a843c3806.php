<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <div class="container">
        <h1>Dashboard</h1>
        <p>Welcome, <strong><?php echo e(Auth::user()->name); ?></strong>!</p>
        <p>You are successfully logged in.</p>

        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" style="background-color: #dc3545;">Logout</button>
        </form>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\LabTask8New\resources\views/dashboard.blade.php ENDPATH**/ ?>